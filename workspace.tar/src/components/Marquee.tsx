import { TICKER } from "../data/catalog";
import { Diamond } from "./ui";

export default function Marquee() {
  const row = (
    <>
      {TICKER.map((t) => (
        <span key={t} className="flex items-center gap-8 shrink-0">
          <span className="font-mono text-[12px] tracking-[0.3em] text-steel whitespace-nowrap">
            {t}
          </span>
          <Diamond className="text-gold shrink-0" />
        </span>
      ))}
    </>
  );

  return (
    <div className="relative border-y border-line bg-onyx overflow-hidden py-5" aria-hidden="true">
      <div className="anim-marquee flex items-center gap-8 w-max">
        {row}
        {row}
      </div>
      <div className="absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-carbon to-transparent pointer-events-none" />
      <div className="absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-carbon to-transparent pointer-events-none" />
    </div>
  );
}
