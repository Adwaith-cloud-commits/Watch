import { useEffect, useRef, useState } from "react";
import { useReducedMotion } from "../hooks";

const N = 6;
const SEGMENTS = 5;

/** Per-frame choreography: scale + offset (normalized to canvas size). */
const KEYS = [
  { s: 0.64, x: 0.0, y: 0.02 },
  { s: 0.8, x: 0.1, y: 0.0 },
  { s: 0.96, x: 0.15, y: -0.02 },
  { s: 1.06, x: 0.06, y: 0.0 },
  { s: 0.9, x: 0.14, y: 0.03 },
  { s: 1.0, x: 0.17, y: -0.01 },
];

interface Caption {
  kicker: string;
  title: string;
  accent: string;
  sub: string;
  cta?: boolean;
}

const CAPTIONS: Caption[] = [
  {
    kicker: "Reference GT-01 · Swiss digital atelier",
    title: "APEX",
    accent: "GT",
    sub: "The first sports instrument finished like haute horlogerie. Scroll — the machine will introduce itself.",
  },
  {
    kicker: "01 · Case",
    title: "Grade-5 titanium,",
    accent: "machined to 4 µm.",
    sub: "Nine hours in a five-axis mill. One octagon, chamfered and hand-polished, sealed in black DLC.",
  },
  {
    kicker: "02 · Dial",
    title: "Sapphire over a dial",
    accent: "that breathes at 120 Hz.",
    sub: "2.5 mm of domed sapphire above an LTPO panel: 1 Hz at rest, 3 000 nits against a noon glacier.",
  },
  {
    kicker: "03 · Interface",
    title: "One crown.",
    accent: "Thirty-one complications.",
    sub: "Twenty-four knurled detents, haptic to the half-gram. Press, turn, hold — the instrument answers.",
  },
  {
    kicker: "04 · Allocation",
    title: "Time,",
    accent: "engineered.",
    sub: "500 numbered units a year, engraved and regulated in Biel/Bienne. From CHF 2 400.",
    cta: true,
  },
];

function smoothstep(t: number): number {
  return t * t * (3 - 2 * t);
}

export default function HeroFrames({ images }: { images: HTMLImageElement[] }) {
  const reduced = useReducedMotion();
  const sectionRef = useRef<HTMLElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const captionRefs = useRef<(HTMLDivElement | null)[]>([]);
  const tickRefs = useRef<(HTMLSpanElement | null)[]>([]);
  const frameNoRef = useRef<HTMLSpanElement>(null);
  const railRef = useRef<HTMLDivElement>(null);
  const cueRef = useRef<HTMLDivElement>(null);
  const glowRef = useRef<HTMLDivElement>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (images.length === N && images.every((img) => img.complete && img.naturalWidth > 0)) {
      setReady(true);
    } else {
      let pending = images.length;
      const tick = () => {
        pending -= 1;
        if (pending <= 0) setReady(true);
      };
      images.forEach((img) => {
        if (img.complete && img.naturalWidth > 0) tick();
        else {
          img.addEventListener("load", tick, { once: true });
          img.addEventListener("error", tick, { once: true });
        }
      });
    }
  }, [images]);

  useEffect(() => {
    if (!ready) return;
    const canvas = canvasRef.current;
    const section = sectionRef.current;
    if (!canvas || !section) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 1.75);
    let w = 0;
    let h = 0;
    let mobile = false;

    const resize = () => {
      const rect = section.getBoundingClientRect();
      w = rect.width;
      h = window.innerHeight;
      mobile = w < 768;
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      targetP = computeP(); // re-draw immediately
      draw(targetP);
    };

    let targetP = 0;
    let drawnP = 0;
    let raf = 0;
    let running = true;
    let lastFrameIdx = -1;

    const computeP = () => {
      const rect = section.getBoundingClientRect();
      const total = rect.height - window.innerHeight;
      if (total <= 0) return 0;
      return Math.min(1, Math.max(0, -rect.top / total));
    };

    const draw = (p: number) => {
      ctx.clearRect(0, 0, w, h);
      const f = p * (N - 1);
      const i = Math.min(Math.floor(f), N - 2);
      const t = smoothstep(f - i);

      const kx = (a: number, b: number) => a + (b - a) * t;
      const k0 = KEYS[i];
      const k1 = KEYS[i + 1];
      let s = kx(k0.s, k1.s);
      let ox = kx(k0.x, k1.x);
      const oy = kx(k0.y, k1.y);
      if (mobile) {
        ox *= 0.22;
        s *= 0.86;
      }

      let bh = h * 0.88;
      let bw = bh * 0.8;
      const maxW = w * (mobile ? 0.94 : 0.9);
      if (bw > maxW) {
        bw = maxW;
        bh = bw / 0.8;
      }
      bw *= s;
      bh *= s;
      const cx = w / 2 + ox * w;
      const cy = h * 0.52 + oy * h;

      const blit = (img: HTMLImageElement, alpha: number) => {
        if (alpha <= 0.004) return;
        ctx.globalAlpha = alpha;
        ctx.drawImage(img, cx - bw / 2, cy - bh / 2, bw, bh);
      };
      blit(images[i], 1);
      blit(images[i + 1], t);
      ctx.globalAlpha = 1;

      /* --- DOM overlays, mutated directly (no React re-renders) --- */
      const idx = Math.round(f);
      if (idx !== lastFrameIdx) {
        lastFrameIdx = idx;
        if (frameNoRef.current) {
          frameNoRef.current.textContent = `${String(idx + 1).padStart(2, "0")} / 06`;
        }
        tickRefs.current.forEach((el, ti) => {
          if (!el) return;
          const active = ti === idx;
          el.style.width = active ? "26px" : "10px";
          el.style.background = active ? "#c9a15f" : "#2c3038";
        });
      }
      if (railRef.current) railRef.current.style.height = `${p * 100}%`;
      if (cueRef.current) cueRef.current.style.opacity = String(Math.max(0, 1 - p * 9));
      if (glowRef.current) {
        glowRef.current.style.opacity = String(0.5 + s * 0.35);
        glowRef.current.style.transform = `translate(-50%, -50%) scale(${0.8 + s * 0.3})`;
      }

      for (let si = 0; si < SEGMENTS; si += 1) {
        const el = captionRefs.current[si];
        if (!el) continue;
        const start = si / SEGMENTS;
        const end = (si + 1) / SEGMENTS;
        const center = (start + end) / 2;
        const fade = 0.055;
        let op = 0;
        if (p >= start - fade && p <= end + fade) {
          op = Math.min(
            1,
            (p - (start - fade)) / fade,
            ((end + fade) - p) / fade
          );
        }
        op = Math.min(1, Math.max(0, op));
        const ty = Math.max(-34, Math.min(34, ((center - p) / 0.11) * 34));
        el.style.opacity = reduced ? (op > 0.5 ? "1" : "0") : op.toFixed(3);
        el.style.transform = `translateY(${reduced ? 0 : ty.toFixed(1)}px)`;
        el.style.pointerEvents = op > 0.55 ? "auto" : "none";
      }
    };

    const loop = () => {
      if (!running) return;
      drawnP += (targetP - drawnP) * (reduced ? 1 : 0.12);
      if (Math.abs(targetP - drawnP) < 0.0004) drawnP = targetP;
      draw(drawnP);
      raf = requestAnimationFrame(loop);
    };

    const onScroll = () => {
      targetP = computeP();
      if (reduced) draw(targetP);
    };

    const io = new IntersectionObserver(
      (entries) => {
        const visible = entries[0]?.isIntersecting ?? false;
        if (visible && !running) {
          running = true;
          raf = requestAnimationFrame(loop);
        } else if (!visible && running) {
          running = false;
          cancelAnimationFrame(raf);
        }
      },
      { threshold: 0 }
    );
    io.observe(section);

    resize();
    window.addEventListener("resize", resize);
    window.addEventListener("scroll", onScroll, { passive: true });
    if (!reduced) raf = requestAnimationFrame(loop);
    else onScroll();

    return () => {
      running = false;
      cancelAnimationFrame(raf);
      io.disconnect();
      window.removeEventListener("resize", resize);
      window.removeEventListener("scroll", onScroll);
    };
  }, [ready, images, reduced]);

  return (
    <section ref={sectionRef} id="top" className="relative h-[520vh]" aria-label="Apex GT scroll sequence">
      <div className="sticky top-0 h-screen overflow-hidden bg-carbon grid-lines">
        {/* ambient gold glow behind the watch */}
        <div
          ref={glowRef}
          className="absolute left-1/2 top-1/2 w-[78vmin] h-[78vmin] rounded-full pointer-events-none"
          style={{
            background:
              "radial-gradient(circle, rgba(201,161,95,0.13) 0%, rgba(201,161,95,0.045) 42%, transparent 68%)",
            transform: "translate(-50%, -50%)",
          }}
        />
        {/* corner registration marks */}
        <div className="absolute top-20 left-6 md:left-10 w-5 h-5 border-t border-l border-line pointer-events-none" aria-hidden="true" />
        <div className="absolute bottom-6 left-6 md:left-10 w-5 h-5 border-b border-l border-line pointer-events-none hidden md:block" aria-hidden="true" />
        <div className="absolute top-20 right-6 md:right-10 w-5 h-5 border-t border-r border-line pointer-events-none" aria-hidden="true" />

        <canvas ref={canvasRef} className="absolute inset-0" />

        {/* captions */}
        {CAPTIONS.map((c, i) => (
          <div
            key={c.kicker}
            ref={(el) => {
              captionRefs.current[i] = el;
            }}
            className="absolute inset-x-6 bottom-[9vh] md:inset-x-auto md:bottom-auto md:left-[5.5vw] md:top-1/2 md:-translate-y-1/2 md:w-[40vw] md:max-w-[600px] will-change-transform"
            style={{ opacity: 0, pointerEvents: "none" }}
          >
            <p className="font-mono text-[11px] tracking-[0.32em] text-gold uppercase mb-4 flex items-center gap-3">
              <span className="inline-block w-8 h-px bg-gold/60 shrink-0" />
              {c.kicker}
            </p>
            <h1 className="font-display font-semibold text-mist leading-[0.98] tracking-tight text-[13.5vw] md:text-[4.6vw] lg:text-[4.2rem]">
              {c.title}{" "}
              <span className="text-gold">{c.accent}</span>
            </h1>
            <p className="mt-5 max-w-md text-steel text-[15px] leading-relaxed">{c.sub}</p>
            {c.cta && (
              <div className="mt-8 flex flex-wrap items-center gap-4">
                <a
                  href="#reserve"
                  className="group inline-flex items-center gap-3 bg-gold text-carbon font-mono text-[12px] font-bold tracking-[0.22em] uppercase px-7 py-4 transition-colors duration-300 hover:bg-goldbright"
                >
                  Reserve yours
                  <svg viewBox="0 0 16 10" className="w-4 h-2.5 transition-transform duration-300 group-hover:translate-x-1" aria-hidden="true">
                    <path d="M0 5h13M9 1l4 4-4 4" stroke="currentColor" strokeWidth="1.6" fill="none" />
                  </svg>
                </a>
                <a
                  href="#anatomy"
                  className="font-mono text-[12px] tracking-[0.22em] uppercase text-mist/80 border-b border-line pb-1 transition-colors duration-300 hover:text-gold hover:border-gold/60"
                >
                  Explore the anatomy
                </a>
              </div>
            )}
          </div>
        ))}

        {/* right rail: frame ticks + counter */}
        <div className="absolute right-6 md:right-10 top-1/2 -translate-y-1/2 flex flex-col items-end gap-4 z-10">
          <span ref={frameNoRef} className="font-mono text-[11px] tracking-[0.3em] text-steel">
            01 / 06
          </span>
          <div className="flex flex-col gap-2.5 items-end">
            {Array.from({ length: N }).map((_, i) => (
              <span
                key={i}
                ref={(el) => {
                  tickRefs.current[i] = el;
                }}
                className="h-[2px] transition-all duration-300"
                style={{ width: i === 0 ? 26 : 10, background: i === 0 ? "#c9a15f" : "#2c3038" }}
              />
            ))}
          </div>
        </div>

        {/* vertical progress rail */}
        <div className="absolute left-6 md:left-10 top-1/2 -translate-y-1/2 h-[38vh] w-px bg-line/70 hidden sm:block">
          <div ref={railRef} className="w-px bg-gold" style={{ height: "0%" }} />
        </div>

        {/* scroll cue */}
        <div ref={cueRef} className="absolute bottom-7 left-1/2 -translate-x-1/2 flex flex-col items-center gap-3 z-10">
          <span className="font-mono text-[10px] tracking-[0.4em] text-steel uppercase">Scroll</span>
          <span className="block w-px h-12 bg-line relative overflow-hidden">
            <span className="anim-cue absolute inset-0 bg-gold" />
          </span>
        </div>

        {/* coordinates */}
        <div className="absolute bottom-7 right-6 md:right-10 hidden md:block text-right font-mono text-[10px] tracking-[0.25em] text-steel/70 leading-relaxed z-10">
          47.1369° N · 7.2466° E<br />BIEL/BIENNE · CH
        </div>

        {/* top fade for nav legibility */}
        <div className="absolute inset-x-0 top-0 h-28 bg-gradient-to-b from-carbon/90 to-transparent pointer-events-none" />
        {/* bottom fade for caption legibility on small screens */}
        <div className="absolute inset-x-0 bottom-0 h-[38vh] md:hidden bg-gradient-to-t from-carbon via-carbon/60 to-transparent pointer-events-none" />
      </div>
    </section>
  );
}
