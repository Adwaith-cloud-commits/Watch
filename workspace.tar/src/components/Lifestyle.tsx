import { IMG } from "../data/catalog";
import { useInView } from "../hooks";

export default function Lifestyle() {
  const [ref, inView] = useInView<HTMLDivElement>(0.3);

  return (
    <section className="relative h-[82vh] min-h-[540px] overflow-hidden border-y border-linedark">
      <div className="absolute inset-0">
        <img
          src={IMG.lifestyle}
          alt="Athlete wearing the Apex GT while running through rain at night"
          loading="lazy"
          decoding="async"
          className="anim-kenburns w-full h-full object-cover"
        />
      </div>
      <div className="absolute inset-0 bg-gradient-to-t from-carbon via-carbon/35 to-carbon/70" />
      <div className="absolute inset-0 bg-gradient-to-r from-carbon/70 via-transparent to-transparent" />

      <p className="absolute top-8 right-6 md:right-10 font-mono text-[10px] tracking-[0.3em] text-mist/70 uppercase text-right leading-relaxed">
        Field test 04<br />Jotunheimen · Norway · −11°C
      </p>

      <div
        ref={ref}
        className={`absolute bottom-0 inset-x-0 p-6 md:p-14 ${inView ? "reveal-in" : ""}`}
      >
        <div className="max-w-[1500px] mx-auto">
          <p className="mask-line">
            <span className="font-display font-semibold text-mist text-3xl sm:text-5xl lg:text-6xl leading-[1.04] tracking-tight">
              “It doesn’t count laps.
            </span>
          </p>
          <p className="mask-line">
            <span
              className="font-display font-semibold text-gold text-3xl sm:text-5xl lg:text-6xl leading-[1.04] tracking-tight"
              style={{ transitionDelay: "120ms" }}
            >
              It makes them matter.”
            </span>
          </p>
          <p
            className="reveal-base font-mono text-[11px] tracking-[0.3em] text-steel uppercase mt-6"
            style={{ transitionDelay: "260ms" }}
          >
            — Field report · Fjellmaraton reconnaissance, 47 km
          </p>
        </div>
      </div>
    </section>
  );
}
