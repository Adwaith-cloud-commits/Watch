import { useEffect, useState, type FormEvent } from "react";
import { api } from "../backend/api";
import { ApiError } from "../backend/types";
import type { ReserveResult } from "../backend/types";
import { EDITIONS } from "../data/catalog";
import { Reveal, SectionHeading, toast } from "./ui";

type Status = "idle" | "loading" | "success";

export default function Reserve() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [wrist, setWrist] = useState("M");
  const [editionId, setEditionId] = useState(EDITIONS[0].id);
  const [status, setStatus] = useState<Status>("idle");
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<ReserveResult | null>(null);

  useEffect(() => {
    const onEdition = (e: Event) => {
      const id = (e as CustomEvent<string>).detail;
      if (EDITIONS.some((ed) => ed.id === id)) setEditionId(id);
    };
    window.addEventListener("kronwerk:edition", onEdition);
    return () => window.removeEventListener("kronwerk:edition", onEdition);
  }, []);

  const edition = EDITIONS.find((e) => e.id === editionId) ?? EDITIONS[0];

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (status === "loading") return;
    setError(null);
    setStatus("loading");
    try {
      const res = await api.reserveUnit({ editionId, name, email, wrist });
      setResult(res);
      setStatus("success");
      toast(`Allocation confirmed — reference ${res.ref}`, "ok");
      window.dispatchEvent(new Event("kronwerk:inventory-changed"));
    } catch (err) {
      const msg =
        err instanceof ApiError ? err.message : "Unexpected ledger error. Try again.";
      setError(msg);
      toast(msg, "err");
      setStatus("idle");
    }
  };

  const reset = () => {
    setStatus("idle");
    setResult(null);
    setName("");
    setEmail("");
    setWrist("M");
    setError(null);
  };

  return (
    <section id="reserve" className="relative py-28 md:py-40 scroll-mt-16 overflow-hidden">
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(55% 45% at 15% 20%, rgba(201,161,95,0.06) 0%, transparent 70%)",
        }}
      />
      <div className="mx-auto max-w-[1500px] px-5 md:px-10 relative">
        <div className="grid lg:grid-cols-[1fr_1fr] gap-16 lg:gap-24">
          <div>
            <SectionHeading kicker="05 — Allocation" lines={["Claim a numbered", "unit."]} />
            <Reveal delay={140}>
              <p className="mt-7 text-steel text-[16px] leading-relaxed max-w-lg">
                Kronwerk builds five hundred Apex GT per year — no more, by statute of the
                house. A reservation holds your number for thirty days and costs nothing;
                the atelier writes to you when your caseback leaves the engraving bench.
              </p>
            </Reveal>
            <Reveal delay={220}>
              <ul className="mt-10 space-y-5">
                {[
                  ["01", "Reserve", "Your name enters the ledger against an edition."],
                  ["02", "Machined", "Your case is milled, regulated and numbered in order."],
                  ["03", "Delivered", "Courier-hand delivery, regulation certificate included."],
                ].map(([no, t, body]) => (
                  <li key={no} className="flex gap-5 border-t border-line pt-5">
                    <span className="font-mono text-[11px] tracking-[0.2em] text-gold pt-1">{no}</span>
                    <div>
                      <p className="font-display font-semibold text-lg text-mist">{t}</p>
                      <p className="text-steel text-[14px] mt-1">{body}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>

          <Reveal delay={180}>
            <div className="border border-line bg-onyx relative">
              <div className="absolute -top-px -left-px w-8 h-8 border-t-2 border-l-2 border-gold" />
              <div className="absolute -bottom-px -right-px w-8 h-8 border-b-2 border-r-2 border-gold" />

              {status === "success" && result ? (
                <div className="p-8 md:p-12">
                  <p className="font-mono text-[11px] tracking-[0.3em] text-gold uppercase flex items-center gap-3">
                    <span className="w-1.5 h-1.5 rounded-full bg-gold anim-pulse-dot" />
                    Allocation confirmed
                  </p>
                  <p className="font-display font-semibold text-5xl md:text-6xl text-mist tracking-tight mt-6">
                    {result.ref}
                  </p>
                  <p className="font-mono text-[12px] tracking-[0.22em] text-steel uppercase mt-3">
                    N° {String(result.position).padStart(3, "0")} of 500 · {edition.name}
                  </p>
                  <div className="mt-8 space-y-3 border-t border-line pt-6">
                    <p className="flex justify-between font-mono text-[12px] tracking-wide">
                      <span className="text-steel">REMAINING IN EDITION</span>
                      <span className="text-mist">{result.remaining}</span>
                    </p>
                    <p className="flex justify-between font-mono text-[12px] tracking-wide">
                      <span className="text-steel">PRICE</span>
                      <span className="text-mist">CHF {edition.price.toLocaleString("en-CH")}</span>
                    </p>
                    <p className="flex justify-between font-mono text-[12px] tracking-wide">
                      <span className="text-steel">HOLD</span>
                      <span className="text-mist">30 DAYS · NO CHARGE</span>
                    </p>
                  </div>
                  <p className="mt-6 text-steel text-[14px] leading-relaxed">
                    The atelier will write to you from Bienne with engraving options and a
                    delivery window. Your number is held in the ledger until then.
                  </p>
                  <button
                    onClick={reset}
                    className="mt-8 font-mono text-[12px] tracking-[0.24em] uppercase text-gold border-b border-gold/50 pb-1 hover:text-goldbright hover:border-goldbright transition-colors"
                  >
                    Reserve another unit
                  </button>
                </div>
              ) : (
                <form onSubmit={submit} className="p-8 md:p-12" noValidate>
                  <p className="font-mono text-[11px] tracking-[0.3em] text-gold uppercase">
                    Reservation ledger
                  </p>
                  <h3 className="font-display font-semibold text-3xl text-mist mt-3 tracking-tight">
                    Enter the queue
                  </h3>

                  <div className="mt-8 space-y-6">
                    <div>
                      <label htmlFor="rw-name" className="block font-mono text-[10px] tracking-[0.28em] uppercase text-steel mb-2.5">
                        Full name
                      </label>
                      <input
                        id="rw-name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Alexandra Moret"
                        autoComplete="name"
                        className="input-dark w-full px-4 py-3.5 font-body text-[15px]"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="rw-email" className="block font-mono text-[10px] tracking-[0.28em] uppercase text-steel mb-2.5">
                        Email
                      </label>
                      <input
                        id="rw-email"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="a.moret@example.com"
                        autoComplete="email"
                        className="input-dark w-full px-4 py-3.5 font-body text-[15px]"
                        required
                      />
                    </div>
                    <div className="grid sm:grid-cols-2 gap-6">
                      <div>
                        <label htmlFor="rw-edition" className="block font-mono text-[10px] tracking-[0.28em] uppercase text-steel mb-2.5">
                          Edition
                        </label>
                        <select
                          id="rw-edition"
                          value={editionId}
                          onChange={(e) => setEditionId(e.target.value)}
                          className="input-dark w-full px-4 py-3.5 font-body text-[15px] appearance-none cursor-pointer"
                        >
                          {EDITIONS.map((ed) => (
                            <option key={ed.id} value={ed.id} className="bg-onyx">
                              {ed.name} — CHF {ed.price.toLocaleString("en-CH")}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <span className="block font-mono text-[10px] tracking-[0.28em] uppercase text-steel mb-2.5">
                          Wrist size
                        </span>
                        <div className="grid grid-cols-3 border border-line" role="radiogroup" aria-label="Wrist size">
                          {["S", "M", "L"].map((s) => (
                            <button
                              key={s}
                              type="button"
                              role="radio"
                              aria-checked={wrist === s}
                              onClick={() => setWrist(s)}
                              className={`py-3.5 font-mono text-[13px] tracking-[0.2em] transition-colors duration-300 ${
                                wrist === s
                                  ? "bg-gold text-carbon font-bold"
                                  : "text-steel hover:text-mist hover:bg-slab"
                              } ${s !== "S" ? "border-l border-line" : ""}`}
                            >
                              {s}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  {error && (
                    <p role="alert" className="mt-6 border border-[#6e2f36] bg-[#1c1214] text-[#f0a9ad] px-4 py-3 font-mono text-[12px] leading-relaxed">
                      {error}
                    </p>
                  )}

                  <button
                    type="submit"
                    disabled={status === "loading"}
                    className="group mt-8 w-full inline-flex items-center justify-center gap-3 bg-gold text-carbon font-mono text-[12px] font-bold tracking-[0.26em] uppercase px-7 py-4.5 transition-all duration-300 hover:bg-goldbright disabled:opacity-60 disabled:cursor-wait"
                  >
                    {status === "loading" ? (
                      <>
                        <span className="w-3.5 h-3.5 border-2 border-carbon/30 border-t-carbon rounded-full animate-spin" />
                        Writing to ledger…
                      </>
                    ) : (
                      <>
                        Reserve {edition.name}
                        <svg viewBox="0 0 16 10" className="w-4 h-2.5 transition-transform duration-300 group-hover:translate-x-1" aria-hidden="true">
                          <path d="M0 5h13M9 1l4 4-4 4" stroke="currentColor" strokeWidth="1.6" fill="none" />
                        </svg>
                      </>
                    )}
                  </button>
                  <p className="mt-4 font-mono text-[10px] tracking-[0.18em] text-steel/70 uppercase text-center">
                    No payment · 30-day hold · POST /v1/reservations
                  </p>
                </form>
              )}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
