import { useEffect, useState } from "react";
import { api } from "../backend/api";
import type { Inventory } from "../backend/types";
import { EDITIONS } from "../data/catalog";
import { Reveal, SectionHeading } from "./ui";

export default function Editions() {
  const [inv, setInv] = useState<Inventory | null>(null);
  const [active, setActive] = useState(0);
  const [error, setError] = useState(false);

  const load = () => {
    api
      .fetchInventory()
      .then(setInv)
      .catch(() => setError(true));
  };

  useEffect(() => {
    load();
    const refresh = () => load();
    window.addEventListener("kronwerk:inventory-changed", refresh);
    return () => window.removeEventListener("kronwerk:inventory-changed", refresh);
  }, []);

  const edition = EDITIONS[active];
  const entry = inv?.[edition.id];
  const remaining = entry?.stock ?? null;
  const total = entry?.total ?? 500;

  return (
    <section id="editions" className="relative py-28 md:py-36 bg-onyx border-y border-linedark scroll-mt-16">
      <div className="mx-auto max-w-[1500px] px-5 md:px-10">
        <div className="mb-14 md:mb-20 flex flex-wrap items-end justify-between gap-8">
          <SectionHeading kicker="04 — Editions" lines={["Three finishes.", "One instrument."]} />
          <Reveal delay={120}>
            <p className="text-steel text-[15px] max-w-sm leading-relaxed">
              Stock is read live from the allocations ledger. When an edition reaches
              zero, it is gone until the next production year.
            </p>
          </Reveal>
        </div>

        <div className="grid lg:grid-cols-[1fr_1.05fr] gap-12 lg:gap-20 items-start">
          {/* selector */}
          <div>
            {error && (
              <p className="font-mono text-[12px] text-[#f0a9ad] mb-4">
                Ledger unreachable — showing catalogue data.
              </p>
            )}
            {EDITIONS.map((e, i) => {
              const stock = inv?.[e.id];
              const pct = stock ? (stock.stock / stock.total) * 100 : null;
              const isActive = active === i;
              return (
                <Reveal key={e.id} delay={i * 90}>
                  <button
                    onClick={() => setActive(i)}
                    aria-pressed={isActive}
                    className={`w-full text-left border-t border-line py-7 group transition-colors duration-300 ${
                      isActive ? "bg-slab/60" : "hover:bg-slab/30"
                    }`}
                    style={{ boxShadow: isActive ? "inset 3px 0 0 0 #c9a15f" : "none" }}
                  >
                    <div className="px-4 md:px-6">
                      <div className="flex items-baseline justify-between gap-4">
                        <div className="flex items-baseline gap-5">
                          <span
                            className={`font-mono text-[11px] tracking-[0.2em] ${
                              isActive ? "text-gold" : "text-steel/70"
                            }`}
                          >
                            0{i + 1}
                          </span>
                          <h3
                            className={`font-display font-semibold text-2xl md:text-3xl tracking-tight transition-colors duration-300 ${
                              isActive ? "text-mist" : "text-steel group-hover:text-mist"
                            }`}
                          >
                            {e.name}
                          </h3>
                        </div>
                        <span className="font-mono text-[14px] text-mist whitespace-nowrap">
                          CHF {e.price.toLocaleString("en-CH")}
                        </span>
                      </div>
                      <div className="mt-2.5 pl-[52px] flex items-center justify-between gap-4">
                        <p className="text-steel text-[13px]">{e.material} · {e.dial}</p>
                        {stock && (
                          <span className="font-mono text-[10px] tracking-[0.18em] uppercase whitespace-nowrap"
                            style={{ color: stock.stock < 200 ? "#d9a05b" : "#8a8f99" }}>
                            {stock.stock} / {stock.total} left
                          </span>
                        )}
                        {!stock && !error && (
                          <span className="anim-shimmer block h-3 w-24" />
                        )}
                      </div>
                      <div className="mt-4 pl-[52px] h-[3px] bg-line/70 overflow-hidden">
                        {pct !== null ? (
                          <div
                            className="h-full transition-all duration-700"
                            style={{ width: `${pct}%`, background: e.accent }}
                          />
                        ) : (
                          <div className="anim-shimmer h-full w-full" />
                        )}
                      </div>
                    </div>
                  </button>
                </Reveal>
              );
            })}
            <div className="border-t border-line" />
            <Reveal delay={280}>
              <p className="mt-6 font-mono text-[11px] tracking-[0.22em] text-steel uppercase leading-loose">
                Every caseback is hand-engraved with its number — N° 001 to N° 500 —
                and delivered with its bench-regulation certificate.
              </p>
            </Reveal>
          </div>

          {/* viewer */}
          <Reveal delay={150}>
            <div className="lg:sticky lg:top-[92px]">
              <div className="relative aspect-[4/5] border border-line bg-carbon overflow-hidden group">
                {EDITIONS.map((e, i) => (
                  <img
                    key={e.id}
                    src={e.image}
                    alt={`${e.name} — ${e.material}`}
                    loading={i === 0 ? "eager" : "lazy"}
                    decoding="async"
                    className={`absolute inset-0 w-full h-full object-cover transition-all duration-700 ${
                      active === i ? "opacity-100 scale-100" : "opacity-0 scale-[1.03]"
                    }`}
                  />
                ))}
                <div className="absolute inset-x-0 bottom-0 p-6 md:p-8 bg-gradient-to-t from-carbon/95 via-carbon/50 to-transparent">
                  <div className="flex items-end justify-between gap-4">
                    <div>
                      <p className="font-mono text-[11px] tracking-[0.28em] uppercase" style={{ color: edition.accent }}>
                        {edition.dial}
                      </p>
                      <p className="font-display font-semibold text-3xl md:text-4xl text-mist mt-1.5 tracking-tight">
                        {edition.name}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-mono text-[13px] text-mist">
                        CHF {edition.price.toLocaleString("en-CH")}
                      </p>
                      <p className="font-mono text-[10px] tracking-[0.2em] text-steel mt-1 uppercase">
                        {remaining !== null ? `${remaining} of ${total} remaining` : "Querying ledger…"}
                      </p>
                    </div>
                  </div>
                </div>
                <svg className="absolute top-4 right-4 w-5 h-5 text-gold/70" viewBox="0 0 20 20" aria-hidden="true">
                  <path d="M20 0v20H0" fill="none" stroke="currentColor" strokeWidth="1.4" />
                </svg>
              </div>
              <a
                href="#reserve"
                onClick={() =>
                  window.dispatchEvent(
                    new CustomEvent("kronwerk:edition", { detail: edition.id })
                  )
                }
                className="group mt-5 w-full inline-flex items-center justify-between border border-line px-6 py-4 font-mono text-[12px] tracking-[0.24em] uppercase text-mist transition-all duration-300 hover:border-gold hover:bg-gold hover:text-carbon"
              >
                Reserve {edition.name}
                <svg viewBox="0 0 16 10" className="w-4 h-2.5 transition-transform duration-300 group-hover:translate-x-1.5" aria-hidden="true">
                  <path d="M0 5h13M9 1l4 4-4 4" stroke="currentColor" strokeWidth="1.6" fill="none" />
                </svg>
              </a>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
