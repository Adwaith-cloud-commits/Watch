import { useEffect, useState, type FormEvent } from "react";
import { api } from "../backend/api";
import { ApiError } from "../backend/types";
import type { ApiLogEntry } from "../backend/types";
import { BrandMark, toast } from "./ui";

export default function Footer() {
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const [lastCall, setLastCall] = useState<ApiLogEntry | null>(null);
  const [counts, setCounts] = useState<{ orders: number; subs: number } | null>(null);

  useEffect(() => {
    let alive = true;
    api.getStatus().then((s) => {
      if (!alive) return;
      setLastCall(s.lastCall);
      setCounts({ orders: s.orders, subs: s.subscribers });
    });
    const onApi = (e: Event) => setLastCall((e as CustomEvent<ApiLogEntry>).detail);
    const onInv = () =>
      api.getStatus().then((s) => {
        if (alive) setCounts({ orders: s.orders, subs: s.subscribers });
      });
    window.addEventListener("kronwerk:api", onApi);
    window.addEventListener("kronwerk:inventory-changed", onInv);
    return () => {
      alive = false;
      window.removeEventListener("kronwerk:api", onApi);
      window.removeEventListener("kronwerk:inventory-changed", onInv);
    };
  }, []);

  const subscribe = async (e: FormEvent) => {
    e.preventDefault();
    if (busy || !email.trim()) return;
    setBusy(true);
    try {
      await api.subscribe(email);
      toast("Welcome to the Meridian List.", "ok");
      setEmail("");
    } catch (err) {
      toast(
        err instanceof ApiError ? err.message : "Subscription failed — try again.",
        "err"
      );
    } finally {
      setBusy(false);
    }
  };

  return (
    <footer id="contact" className="relative bg-onyx border-t border-line">
      {/* newsletter band */}
      <div className="border-b border-line">
        <div className="mx-auto max-w-[1500px] px-5 md:px-10 py-16 md:py-20 grid lg:grid-cols-2 gap-10 items-center">
          <div>
            <p className="font-mono text-[11px] tracking-[0.32em] text-gold uppercase mb-4 flex items-center gap-3">
              <span className="inline-block w-8 h-px bg-gold/60" />
              The Meridian List
            </p>
            <h2 className="font-display font-semibold text-3xl md:text-5xl text-mist tracking-tight leading-[1.03]">
              Field notes, drops and<br />
              <span className="text-gold">bench reports.</span> Once a month.
            </h2>
          </div>
          <form onSubmit={subscribe} className="flex flex-col sm:flex-row gap-3">
            <label htmlFor="nl-email" className="sr-only">
              Email address
            </label>
            <input
              id="nl-email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="input-dark flex-1 px-5 py-4 font-body text-[15px]"
            />
            <button
              type="submit"
              disabled={busy}
              className="group inline-flex items-center justify-center gap-3 border border-gold text-gold font-mono text-[12px] font-medium tracking-[0.26em] uppercase px-8 py-4 transition-all duration-300 hover:bg-gold hover:text-carbon disabled:opacity-60"
            >
              {busy ? (
                <>
                  <span className="w-3.5 h-3.5 border-2 border-current/30 border-t-current rounded-full animate-spin" />
                  Syncing
                </>
              ) : (
                <>
                  Subscribe
                  <svg viewBox="0 0 16 10" className="w-4 h-2.5 transition-transform duration-300 group-hover:translate-x-1" aria-hidden="true">
                    <path d="M0 5h13M9 1l4 4-4 4" stroke="currentColor" strokeWidth="1.6" fill="none" />
                  </svg>
                </>
              )}
            </button>
          </form>
        </div>
      </div>

      {/* columns */}
      <div className="mx-auto max-w-[1500px] px-5 md:px-10 py-16 grid sm:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1.2fr] gap-12">
        <div>
          <a href="#top" className="flex items-center gap-3 text-mist">
            <BrandMark className="w-7 h-7 text-mist" />
            <span className="font-display font-semibold tracking-[0.28em] text-[15px]">KRONWERK</span>
          </a>
          <p className="mt-5 text-steel text-[14px] leading-relaxed max-w-xs">
            Digital haute horlogerie, machined and regulated in Biel/Bienne since the
            house was founded on a single conviction: a processor is a complication.
          </p>
          <p className="mt-6 font-mono text-[10px] tracking-[0.24em] text-steel/70 uppercase leading-loose">
            Est. MMXXIV · Bienne, CH<br />
            {counts ? `${counts.orders} reservations · ${counts.subs} subscribers on-ledger` : "Ledger syncing…"}
          </p>
        </div>

        <nav aria-label="Instrument">
          <p className="font-mono text-[10px] tracking-[0.3em] uppercase text-steel/70 mb-5">Instrument</p>
          <ul className="space-y-3.5">
            {[
              ["Performance", "#performance"],
              ["Anatomy", "#anatomy"],
              ["The Dial", "#dial"],
              ["Editions", "#editions"],
              ["Reserve", "#reserve"],
            ].map(([label, href]) => (
              <li key={href}>
                <a href={href} className="text-[14px] text-mist/85 hover:text-gold transition-colors duration-300">
                  {label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <nav aria-label="Maison">
          <p className="font-mono text-[10px] tracking-[0.3em] uppercase text-steel/70 mb-5">Maison</p>
          <ul className="space-y-3.5 text-[14px]">
            <li>
              <a href="mailto:atelier@kronwerk.example" className="text-mist/85 hover:text-gold transition-colors duration-300">
                atelier@kronwerk.example
              </a>
            </li>
            <li>
              <a href="tel:+41320000500" className="text-mist/85 hover:text-gold transition-colors duration-300">
                +41 32 000 05 00
              </a>
            </li>
            <li>
              <a href="#top" className="text-mist/85 hover:text-gold transition-colors duration-300">
                Back to the sequence ↑
              </a>
            </li>
          </ul>
        </nav>

        <div>
          <p className="font-mono text-[10px] tracking-[0.3em] uppercase text-steel/70 mb-5">Atelier</p>
          <address className="not-italic text-[14px] text-mist/85 leading-relaxed">
            Kronwerk SA<br />
            Rue de la Gare 17<br />
            2502 Biel/Bienne · Switzerland
          </address>
          <p className="mt-5 font-mono text-[11px] tracking-[0.18em] text-steel uppercase leading-loose">
            Visits by appointment<br />Tue – Sat · 10:00 – 18:00 CET
          </p>
        </div>
      </div>

      {/* api status strip */}
      <div className="border-t border-line">
        <div className="mx-auto max-w-[1500px] px-5 md:px-10 py-5 flex flex-wrap items-center gap-x-8 gap-y-3 font-mono text-[10px] tracking-[0.22em] uppercase">
          <span className="flex items-center gap-2.5 text-[#9fe8c0]">
            <span className="w-1.5 h-1.5 rounded-full bg-[#5fd39a] anim-pulse-dot" />
            Ledger API · Online
          </span>
          {lastCall ? (
            <span className="text-steel">
              Last call — {lastCall.endpoint} · {lastCall.ms} ms · {lastCall.code}
            </span>
          ) : (
            <span className="text-steel">Awaiting first call…</span>
          )}
          <span className="ml-auto text-steel/60">
            v1.4.2 · edge: ZRH-01
          </span>
        </div>
      </div>

      <div className="border-t border-linedark">
        <div className="mx-auto max-w-[1500px] px-5 md:px-10 py-6 flex flex-wrap items-center justify-between gap-4">
          <p className="font-mono text-[10px] tracking-[0.22em] text-steel/60 uppercase">
            © 2026 Kronwerk SA — a crafted concept, fictional product
          </p>
          <p className="font-mono text-[10px] tracking-[0.22em] text-steel/60 uppercase">
            CHF · EN · 47.1369° N
          </p>
        </div>
      </div>
    </footer>
  );
}
