import { useEffect, useRef } from "react";
import { useInView } from "../hooks";
import { IconDepth, IconOrbit, IconPulse, IconShield, Reveal, SectionHeading } from "./ui";

const RING_R = 132;
const CIRC = 2 * Math.PI * RING_R;
const DAY_R = 112;
const DAY_CIRC = 2 * Math.PI * DAY_R;

const FEATURES = [
  {
    icon: IconPulse,
    title: "Optical pulse, every second",
    body: "Medical-grade PPG sampled at 1 Hz with motion cancellation.",
  },
  {
    icon: IconOrbit,
    title: "Dual-band GNSS",
    body: "L1 + L5 lock in under nine seconds, track for nine hours.",
  },
  {
    icon: IconDepth,
    title: "Dive computer to 100 m",
    body: "EN 22810 certified, Bühlmann ZHL-16C with gradient factors.",
  },
  {
    icon: IconShield,
    title: "Titanium for a decade",
    body: "DLC-sealed case, 10-year movement service interval.",
  },
];

export default function LiveDial() {
  const [ref, inView] = useInView<HTMLDivElement>(0.3);
  const timeRef = useRef<HTMLSpanElement>(null);
  const msRef = useRef<HTMLSpanElement>(null);
  const ringRef = useRef<SVGCircleElement>(null);
  const dayRef = useRef<SVGCircleElement>(null);
  const waveRef = useRef<SVGPolylineElement>(null);

  useEffect(() => {
    if (!inView) return;
    let raf = 0;
    const waveBuf: number[] = Array.from({ length: 72 }, () => 30);
    let lastSec = -1;

    const tick = () => {
      const now = new Date();
      const s = now.getSeconds();
      const ms = now.getMilliseconds();

      if (timeRef.current && s !== lastSec) {
        lastSec = s;
        const pad = (n: number) => String(n).padStart(2, "0");
        timeRef.current.textContent = `${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(s)}`;
        const days = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];
        const months = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
        const dateEl = document.getElementById("livedial-date");
        if (dateEl) {
          dateEl.textContent = `${days[now.getDay()]} ${pad(now.getDate())} ${months[now.getMonth()]} ${now.getFullYear()}`;
        }
      }
      if (msRef.current) msRef.current.textContent = `.${String(ms).padStart(3, "0")}`;

      const secFrac = (s + ms / 1000) / 60;
      if (ringRef.current) {
        ringRef.current.style.strokeDashoffset = String(CIRC * (1 - secFrac));
      }
      const dayFrac =
        (now.getHours() * 3600 + now.getMinutes() * 60 + s) / 86400;
      if (dayRef.current) {
        dayRef.current.style.strokeDashoffset = String(DAY_CIRC * (1 - dayFrac));
      }

      const t = now.getTime() / 1000;
      waveBuf.push(
        30 +
          Math.sin(t * 5.2) * 9 +
          Math.sin(t * 13.7) * 4 +
          (Math.random() - 0.5) * 3
      );
      waveBuf.shift();
      if (waveRef.current) {
        waveRef.current.setAttribute(
          "points",
          waveBuf.map((v, i) => `${(i / (waveBuf.length - 1)) * 260},${v}`).join(" ")
        );
      }

      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView]);

  const ticks = Array.from({ length: 60 }, (_, i) => {
    const a = (i / 60) * Math.PI * 2 - Math.PI / 2;
    const major = i % 5 === 0;
    const r1 = major ? 140 : 144;
    const r2 = 150;
    return (
      <line
        key={i}
        x1={160 + Math.cos(a) * r1}
        y1={160 + Math.sin(a) * r1}
        x2={160 + Math.cos(a) * r2}
        y2={160 + Math.sin(a) * r2}
        stroke={major ? "#8a8f99" : "#2c3038"}
        strokeWidth={major ? 1.6 : 1}
      />
    );
  });

  return (
    <section id="dial" className="relative py-28 md:py-40 overflow-hidden scroll-mt-16">
      {/* ambient backdrop */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(60% 55% at 78% 45%, rgba(201,161,95,0.07) 0%, transparent 70%)",
        }}
      />
      <div className="mx-auto max-w-[1500px] px-5 md:px-10 relative">
        <div className="grid lg:grid-cols-[1.15fr_1fr] gap-16 lg:gap-10 items-center">
          <div>
            <SectionHeading kicker="03 — The Dial" lines={["Always on.", "Like you."]} />
            <Reveal delay={140}>
              <p className="mt-7 text-steel text-[16px] leading-relaxed max-w-xl">
                The Apex GT never blacks out. Its LTPO panel steps down to one refresh per
                second in always-on mode and still holds the reserve for three weeks — then
                wakes to 120 Hz the moment your wrist turns. What you see on the right is
                not a render. It is your local time, drawn live by this page.
              </p>
            </Reveal>
            <div className="mt-12 grid sm:grid-cols-2 gap-x-10 gap-y-9">
              {FEATURES.map((f, i) => (
                <Reveal key={f.title} delay={i * 90} className="group">
                  <div className="flex items-center gap-3 text-gold">
                    <f.icon className="w-5 h-5 transition-transform duration-300 group-hover:-translate-y-0.5" />
                    <h3 className="font-mono text-[12px] tracking-[0.2em] uppercase text-mist/90">
                      {f.title}
                    </h3>
                  </div>
                  <p className="mt-2.5 text-steel text-[14px] leading-relaxed">{f.body}</p>
                </Reveal>
              ))}
            </div>
          </div>

          {/* live dial */}
          <div ref={ref} className="relative flex flex-col items-center">
            <Reveal delay={100} className="relative w-[min(88vw,420px)]">
              <div className="relative border border-line bg-onyx px-8 pt-10 pb-8">
                <svg viewBox="0 0 320 320" className="w-full" role="img" aria-label="Live seconds and day-progress dial">
                  {ticks}
                  <circle cx="160" cy="160" r={RING_R} fill="none" stroke="#1d2027" strokeWidth="3" />
                  <circle
                    ref={ringRef}
                    cx="160"
                    cy="160"
                    r={RING_R}
                    fill="none"
                    stroke="#c9a15f"
                    strokeWidth="3"
                    strokeLinecap="round"
                    strokeDasharray={CIRC}
                    strokeDashoffset={CIRC}
                    transform="rotate(-90 160 160)"
                  />
                  <circle cx="160" cy="160" r={DAY_R} fill="none" stroke="#1d2027" strokeWidth="1.5" />
                  <circle
                    ref={dayRef}
                    cx="160"
                    cy="160"
                    r={DAY_R}
                    fill="none"
                    stroke="#4d5460"
                    strokeWidth="1.5"
                    strokeDasharray={DAY_CIRC}
                    strokeDashoffset={DAY_CIRC}
                    transform="rotate(-90 160 160)"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                  <p className="font-mono text-[10px] tracking-[0.4em] text-gold uppercase">Local · UTC+01</p>
                  <p className="font-display font-semibold text-[13vw] sm:text-[52px] leading-none text-mist mt-3 tabular-nums tracking-tight">
                    <span ref={timeRef}>--:--:--</span>
                    <span ref={msRef} className="text-gold text-[0.42em] align-baseline">.000</span>
                  </p>
                  <p id="livedial-date" className="font-mono text-[11px] tracking-[0.3em] text-steel mt-3">
                    — — —
                  </p>
                  <svg viewBox="0 0 260 60" className="w-[70%] mt-5 text-gold" aria-hidden="true">
                    <polyline
                      ref={waveRef}
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.6"
                      opacity="0.85"
                    />
                  </svg>
                  <p className="font-mono text-[9px] tracking-[0.35em] text-steel/70 mt-3">
                    OPTICAL PULSE · 1 HZ
                  </p>
                </div>
              </div>
              <div className="flex items-center justify-between mt-4 font-mono text-[10px] tracking-[0.28em] text-steel/80 uppercase">
                <span className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-gold anim-pulse-dot" />
                  Live signal
                </span>
                <span>AOD · 3 000 NITS</span>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
