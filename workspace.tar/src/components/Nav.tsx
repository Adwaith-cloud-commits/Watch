import { useEffect, useState } from "react";
import { BrandMark } from "./ui";

const LINKS = [
  { label: "Performance", href: "#performance" },
  { label: "Anatomy", href: "#anatomy" },
  { label: "The Dial", href: "#dial" },
  { label: "Editions", href: "#editions" },
];

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-[60] transition-all duration-500 border-b ${
        scrolled ? "bg-carbon/92 border-line backdrop-blur-sm" : "bg-transparent border-transparent"
      }`}
    >
      <div className="mx-auto max-w-[1500px] px-5 md:px-10 h-[68px] flex items-center justify-between gap-6">
        <a href="#top" className="flex items-center gap-3 text-mist group" aria-label="Kronwerk home">
          <BrandMark className="w-7 h-7 text-mist transition-transform duration-500 group-hover:rotate-[30deg]" />
          <span className="font-display font-semibold tracking-[0.28em] text-[15px]">
            KRONWERK
          </span>
        </a>

        <nav className="hidden lg:flex items-center gap-9" aria-label="Primary">
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="font-mono text-[11px] tracking-[0.28em] uppercase text-steel transition-colors duration-300 hover:text-gold relative after:absolute after:-bottom-1.5 after:left-0 after:h-px after:w-0 after:bg-gold after:transition-all after:duration-300 hover:after:w-full"
            >
              {l.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-5">
          <span className="hidden md:block font-mono text-[11px] tracking-[0.2em] text-steel">
            CHF 2 400
          </span>
          <a
            href="#reserve"
            className="hidden sm:inline-flex items-center gap-2 border border-gold/70 text-gold font-mono text-[11px] font-medium tracking-[0.26em] uppercase px-5 py-2.5 transition-all duration-300 hover:bg-gold hover:text-carbon"
          >
            Reserve
          </a>
          <button
            onClick={() => setOpen((v) => !v)}
            className="lg:hidden text-mist p-2 -mr-2"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
          >
            <svg viewBox="0 0 22 16" className="w-[22px] h-4" aria-hidden="true">
              <path
                d={open ? "M2 2l18 12M20 2L2 14" : "M1 2h20M1 8h13M1 14h20"}
                stroke="currentColor"
                strokeWidth="1.6"
                strokeLinecap="round"
              />
            </svg>
          </button>
        </div>
      </div>

      {/* mobile panel */}
      <div
        className={`lg:hidden overflow-hidden border-b border-line bg-carbon/97 transition-all duration-400 ${
          open ? "max-h-72" : "max-h-0 border-b-0"
        }`}
      >
        <nav className="px-6 py-5 flex flex-col gap-4" aria-label="Mobile">
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="font-mono text-[12px] tracking-[0.28em] uppercase text-steel hover:text-gold transition-colors"
            >
              {l.label}
            </a>
          ))}
          <a
            href="#reserve"
            onClick={() => setOpen(false)}
            className="font-mono text-[12px] tracking-[0.28em] uppercase text-gold"
          >
            Reserve →
          </a>
        </nav>
      </div>
    </header>
  );
}
