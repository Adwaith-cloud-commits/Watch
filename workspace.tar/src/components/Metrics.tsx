import { METRICS } from "../data/catalog";
import { useCountUp, useInView, useReducedMotion } from "../hooks";
import { Reveal, SectionHeading } from "./ui";

function Stat({
  value,
  suffix,
  label,
  note,
  delay,
  inView,
}: {
  value: number;
  suffix: string;
  label: string;
  note: string;
  delay: number;
  inView: boolean;
}) {
  const reduced = useReducedMotion();
  const n = useCountUp(value, inView, 1500 + delay, reduced);
  return (
    <Reveal delay={delay} className="border-t border-line pt-7 group">
      <p className="font-display font-semibold text-mist text-5xl md:text-6xl tracking-tight tabular-nums transition-colors duration-300 group-hover:text-goldbright">
        {Math.round(n)}
        <span className="text-gold text-2xl md:text-3xl align-baseline ml-1 font-medium">{suffix}</span>
      </p>
      <p className="mt-3 font-mono text-[11px] tracking-[0.28em] uppercase text-mist/85">{label}</p>
      <p className="mt-1 text-steel text-[13px]">{note}</p>
    </Reveal>
  );
}

export default function Metrics() {
  const [ref, inView] = useInView<HTMLDivElement>(0.3);

  return (
    <section id="performance" className="relative py-28 md:py-40 scroll-mt-16">
      <div className="mx-auto max-w-[1500px] px-5 md:px-10">
        <div className="grid lg:grid-cols-[1fr_1.2fr] gap-14 lg:gap-20 items-end mb-16 md:mb-24">
          <SectionHeading
            kicker="01 — Performance"
            lines={["Built like an instrument.", "Worn like a trophy."]}
          />
          <Reveal delay={150} className="lg:pb-2">
            <p className="text-steel text-[16px] leading-relaxed max-w-xl lg:ml-auto">
              Most sports watches are appliances. The Apex GT is regulated, engraved and
              tested the way a grand complication is — then given a processor fast enough
              to disappear. Every number below is measured on the bench in Bienne, not in
              a press release.
            </p>
            <p className="mt-6 font-mono text-[11px] tracking-[0.25em] text-gold/80 uppercase">
              Bench report № 0047 · Rev C
            </p>
          </Reveal>
        </div>

        <div ref={ref} className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-x-8 gap-y-12">
          {METRICS.map((m, i) => (
            <Stat key={m.label} {...m} delay={i * 110} inView={inView} />
          ))}
        </div>
      </div>
    </section>
  );
}
