import { useEffect, useState } from "react";
import { useReducedMotion, useScramble } from "../hooks";
import { BrandMark } from "./ui";

const LOGS = [
  { at: 0.12, text: "CALIBRE M-2 · REGULATOR" },
  { at: 0.34, text: "SAPPHIRE BOND · 2.5 MM" },
  { at: 0.56, text: "GNSS DUAL-BAND · LOCK" },
  { at: 0.78, text: "ALLOCATIONS LEDGER · SYNC" },
];

export default function BootLoader({
  progress,
  ready,
  onDone,
}: {
  progress: number;
  ready: boolean;
  onDone: () => void;
}) {
  const reduced = useReducedMotion();
  const [fading, setFading] = useState(false);
  const [gone, setGone] = useState(false);
  const title = useScramble("KRONWERK", true, reduced);

  useEffect(() => {
    if (!ready || gone) return;
    const wait = reduced ? 120 : 620;
    const t = window.setTimeout(() => setFading(true), wait);
    return () => window.clearTimeout(t);
  }, [ready, reduced, gone]);

  useEffect(() => {
    if (!fading) return;
    const t = window.setTimeout(() => {
      setGone(true);
      onDone();
    }, reduced ? 30 : 460);
    return () => window.clearTimeout(t);
  }, [fading, reduced, onDone]);

  if (gone) return null;

  return (
    <div
      className={`fixed inset-0 z-[100] bg-carbon flex items-center justify-center transition-opacity duration-500 ${
        fading ? "opacity-0" : "opacity-100"
      }`}
      aria-hidden={fading}
    >
      <div className="w-[min(88vw,420px)]">
        <div className="flex items-center gap-3 mb-6">
          <BrandMark className="w-8 h-8 text-mist" />
          <span className="font-display font-semibold tracking-[0.34em] text-mist text-xl">
            {title || "\u00A0"}
          </span>
        </div>

        <div className="h-px bg-line relative overflow-hidden mb-6">
          <div
            className="absolute inset-y-0 left-0 bg-gold transition-[width] duration-300 ease-out"
            style={{ width: `${Math.round(progress * 100)}%` }}
          />
        </div>

        <div className="space-y-2 min-h-[92px]">
          {LOGS.map((l) => (
            <p
              key={l.text}
              className={`font-mono text-[11px] tracking-[0.22em] flex justify-between transition-opacity duration-500 ${
                progress >= l.at ? "opacity-100" : "opacity-0"
              }`}
            >
              <span className="text-steel">{l.text}</span>
              <span className="text-gold">OK</span>
            </p>
          ))}
          <p className="font-mono text-[11px] tracking-[0.22em] text-steel/60 flex justify-between">
            <span>LOADING SEQUENCE 001–006</span>
            <span>{Math.round(progress * 100)}%</span>
          </p>
        </div>
      </div>
    </div>
  );
}
