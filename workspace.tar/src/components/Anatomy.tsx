import { useEffect, useRef, useState } from "react";
import { ANATOMY } from "../data/catalog";
import { Reveal, SectionHeading } from "./ui";

export default function Anatomy() {
  const [active, setActive] = useState(0);
  const itemRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            const idx = Number((e.target as HTMLElement).dataset.idx ?? 0);
            setActive(idx);
          }
        }
      },
      { rootMargin: "-42% 0px -42% 0px", threshold: 0 }
    );
    itemRefs.current.forEach((el) => el && io.observe(el));
    return () => io.disconnect();
  }, []);

  const current = ANATOMY[active];

  return (
    <section id="anatomy" className="relative py-28 md:py-36 bg-onyx border-y border-linedark scroll-mt-16">
      <div className="mx-auto max-w-[1500px] px-5 md:px-10">
        <div className="mb-16 md:mb-24 max-w-2xl">
          <SectionHeading
            kicker="02 — Anatomy"
            lines={["Five components.", "Zero compromise."]}
          />
        </div>

        <div className="grid lg:grid-cols-[1fr_1fr] gap-14 lg:gap-24">
          {/* sticky viewer */}
          <div className="hidden lg:block">
            <div className="sticky top-[92px]">
              <div className="relative aspect-[4/5] border border-line bg-carbon overflow-hidden">
                {ANATOMY.map((item, i) => (
                  <img
                    key={item.no}
                    src={item.image}
                    alt={item.title}
                    loading={i === 0 ? "eager" : "lazy"}
                    decoding="async"
                    className="absolute inset-0 w-full h-full object-cover transition-opacity duration-700"
                    style={{ opacity: active === i ? 1 : 0 }}
                  />
                ))}
                <div className="absolute inset-x-0 bottom-0 p-6 bg-gradient-to-t from-carbon/95 via-carbon/55 to-transparent">
                  <p className="font-mono text-[11px] tracking-[0.3em] text-gold uppercase">
                    Component {current.no} / 05
                  </p>
                  <p className="font-display font-semibold text-2xl text-mist mt-1.5">
                    {current.title}
                  </p>
                  <p className="font-mono text-[11px] tracking-[0.18em] text-steel mt-1.5">
                    {current.spec}
                  </p>
                </div>
                {/* corner marks */}
                <svg className="absolute top-4 left-4 w-5 h-5 text-gold/70" viewBox="0 0 20 20" aria-hidden="true">
                  <path d="M0 20V0h20" fill="none" stroke="currentColor" strokeWidth="1.4" />
                </svg>
                <svg className="absolute bottom-4 right-4 w-5 h-5 text-gold/70" viewBox="0 0 20 20" aria-hidden="true">
                  <path d="M20 0v20H0" fill="none" stroke="currentColor" strokeWidth="1.4" />
                </svg>
              </div>
              {/* index rail */}
              <div className="mt-5 flex items-center gap-2">
                {ANATOMY.map((item, i) => (
                  <button
                    key={item.no}
                    onClick={() => {
                      itemRefs.current[i]?.scrollIntoView({ block: "center", behavior: "smooth" });
                    }}
                    aria-label={`Go to ${item.title}`}
                    className="h-1 transition-all duration-400"
                    style={{
                      width: active === i ? 44 : 16,
                      background: active === i ? "#c9a15f" : "#23262e",
                    }}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* scrolling components */}
          <div>
            {ANATOMY.map((item, i) => (
              <div
                key={item.no}
                data-idx={i}
                ref={(el) => {
                  itemRefs.current[i] = el;
                }}
                className="min-h-[58vh] flex flex-col justify-center border-t border-line first:border-t-0 py-10"
              >
                <Reveal>
                  <div className="flex items-baseline gap-6">
                    <span
                      className={`font-display font-semibold text-6xl md:text-7xl tracking-tight transition-colors duration-500 ${
                        active === i ? "text-gold" : "text-line"
                      }`}
                    >
                      {item.no}
                    </span>
                    <div>
                      <h3 className="font-display font-semibold text-2xl md:text-3xl text-mist">
                        {item.title}
                      </h3>
                      <p className="font-mono text-[11px] tracking-[0.22em] uppercase text-gold/85 mt-1.5">
                        {item.spec}
                      </p>
                    </div>
                  </div>
                  <p className="mt-6 text-steel text-[15.5px] leading-relaxed max-w-xl">
                    {item.body}
                  </p>
                  {/* mobile viewer */}
                  <div className="lg:hidden mt-7 relative aspect-[16/10] border border-line overflow-hidden">
                    <img
                      src={item.image}
                      alt={item.title}
                      loading="lazy"
                      decoding="async"
                      className="absolute inset-0 w-full h-full object-cover"
                    />
                  </div>
                </Reveal>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
