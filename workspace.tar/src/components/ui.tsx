import { useCallback, useEffect, useState, type ReactNode } from "react";
import { useInView } from "../hooks";

/* ---------------- Reveal wrapper ---------------- */
export function Reveal({
  children,
  delay = 0,
  className = "",
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
}) {
  const [ref, inView] = useInView<HTMLDivElement>(0.18);
  return (
    <div
      ref={ref}
      className={`reveal-base ${inView ? "reveal-in" : ""} ${className}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
}

/* ---------------- Section heading with line-mask reveal ---------------- */
export function SectionHeading({
  kicker,
  lines,
  align = "left",
}: {
  kicker: string;
  lines: string[];
  align?: "left" | "center";
}) {
  const [ref, inView] = useInView<HTMLDivElement>(0.4);
  return (
    <div
      ref={ref}
      className={`${inView ? "reveal-in" : ""} ${
        align === "center" ? "text-center" : ""
      }`}
    >
      <p className="font-mono text-[11px] tracking-[0.35em] text-gold uppercase mb-5 flex items-center gap-3">
        {align === "left" && <span className="inline-block w-8 h-px bg-gold/60" />}
        {kicker}
      </p>
      <h2 className="font-display font-semibold text-mist leading-[1.02] text-4xl sm:text-5xl lg:text-6xl tracking-tight">
        {lines.map((line, i) => (
          <span className="mask-line" key={line}>
            <span style={{ transitionDelay: `${i * 110}ms` }}>{line}</span>
          </span>
        ))}
      </h2>
    </div>
  );
}

/* ---------------- Diamond separator (ticker) ---------------- */
export function Diamond({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 10 10" className={`w-2 h-2 ${className}`} aria-hidden="true">
      <path d="M5 0 10 5 5 10 0 5Z" fill="currentColor" />
    </svg>
  );
}

/* ---------------- Brand mark ---------------- */
export function BrandMark({ className = "w-6 h-6" }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
      <path d="M16 2 28 9v14L16 30 4 23V9Z" fill="none" stroke="currentColor" strokeWidth="1.6" />
      <path d="M16 8.5 22.5 12.25v7.5L16 23.5l-6.5-3.75v-7.5Z" fill="none" stroke="#c9a15f" strokeWidth="1.4" />
      <circle cx="16" cy="16" r="2.1" fill="#c9a15f" />
      <path d="M16 16V9.8M16 16l4.8 3.4" stroke="#c9a15f" strokeWidth="1.4" strokeLinecap="round" />
    </svg>
  );
}

/* ---------------- Custom inline icons ---------------- */
export function IconDepth({ className = "w-5 h-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
      <path d="M3 6.5c2 1.6 4 1.6 6 0s4-1.6 6 0 4 1.6 6 0" strokeLinecap="round" />
      <path d="M3 12c2 1.6 4 1.6 6 0s4-1.6 6 0 4 1.6 6 0" strokeLinecap="round" opacity="0.65" />
      <path d="M3 17.5c2 1.6 4 1.6 6 0s4-1.6 6 0 4 1.6 6 0" strokeLinecap="round" opacity="0.35" />
    </svg>
  );
}

export function IconPulse({ className = "w-5 h-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
      <path d="M2.5 12h4l2.5-6 4 12 2.5-6h6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function IconOrbit({ className = "w-5 h-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
      <circle cx="12" cy="12" r="3.2" />
      <path d="M20.3 8.6c1.6 3.9-1 9.2-6 11.4S4.4 20.6 3.7 15.4" strokeLinecap="round" />
      <path d="M3.7 15.4C2.1 11.5 4.7 6.2 9.7 4S19.6 3.4 20.3 8.6" strokeLinecap="round" opacity="0.5" />
    </svg>
  );
}

export function IconShield({ className = "w-5 h-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
      <path d="M12 2.8 20 6v6.2c0 4.6-3.4 7.9-8 9-4.6-1.1-8-4.4-8-9V6Z" strokeLinejoin="round" />
      <path d="m8.6 11.8 2.3 2.3 4.5-4.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

/* ---------------- Toast system ---------------- */
interface Toast {
  id: number;
  message: string;
  kind: "ok" | "err" | "info";
}

let toastId = 0;

export function toast(message: string, kind: Toast["kind"] = "info"): void {
  toastId += 1;
  window.dispatchEvent(
    new CustomEvent("kronwerk:toast", { detail: { id: toastId, message, kind } })
  );
}

export function ToastHost() {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const dismiss = useCallback((id: number) => {
    setToasts((t) => t.filter((x) => x.id !== id));
  }, []);

  useEffect(() => {
    const onToast = (e: Event) => {
      const detail = (e as CustomEvent<Toast>).detail;
      setToasts((t) => [...t.slice(-2), detail]);
      window.setTimeout(() => dismiss(detail.id), 4200);
    };
    window.addEventListener("kronwerk:toast", onToast);
    return () => window.removeEventListener("kronwerk:toast", onToast);
  }, [dismiss]);

  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[90] flex flex-col gap-2 items-center pointer-events-none px-4">
      {toasts.map((t) => (
        <div
          key={t.id}
          role="status"
          className={`anim-toast pointer-events-auto font-mono text-[12px] tracking-wide px-5 py-3 border flex items-center gap-3 max-w-[92vw] ${
            t.kind === "ok"
              ? "bg-[#101a14] border-[#2c5e42] text-[#9fe8c0]"
              : t.kind === "err"
              ? "bg-[#1c1214] border-[#6e2f36] text-[#f0a9ad]"
              : "bg-onyx border-line text-steel"
          }`}
        >
          <span
            className={`w-1.5 h-1.5 rounded-full shrink-0 ${
              t.kind === "ok" ? "bg-[#5fd39a]" : t.kind === "err" ? "bg-[#e06a72]" : "bg-gold"
            }`}
          />
          {t.message}
        </div>
      ))}
    </div>
  );
}
