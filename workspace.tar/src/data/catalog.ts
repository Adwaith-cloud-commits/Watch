export const IMG = {
  frames: [
    "https://image.qwenlm.ai/generated-images/de3e11b3-ab19-4915-8b89-861088554d8e/_result.png",
    "https://image.qwenlm.ai/generated-images/2fa6edbc-0a58-4504-bf67-15c0d035a7df/_result.png",
    "https://image.qwenlm.ai/generated-images/5334eb32-a1b6-4b9d-bec9-603f4c17ca10/_result.png",
    "https://image.qwenlm.ai/generated-images/79c07dfd-937e-46f4-a613-50aa8699de21/_result.png",
    "https://image.qwenlm.ai/generated-images/a1120775-448c-4573-b417-e2d2a9959871/_result.png",
    "https://image.qwenlm.ai/generated-images/b9670c55-688f-4239-813d-f66eeae68812/_result.png",
  ],
  editionGlacier:
    "https://image.qwenlm.ai/generated-images/3393bbb8-d44c-4280-bbbc-43faa27243ff/_result.png",
  editionAurum:
    "https://image.qwenlm.ai/generated-images/5ade391e-98d4-4c5a-8c62-0b236ca269e2/_result.png",
  lifestyle:
    "https://image.qwenlm.ai/generated-images/7faaeea2-92e7-4c11-b82f-64d6d11fd544/_result.png",
} as const;

export interface Edition {
  id: string;
  name: string;
  material: string;
  dial: string;
  price: number;
  image: string;
  accent: string;
}

export const EDITIONS: Edition[] = [
  {
    id: "stealth",
    name: "Stealth GT",
    material: "Micro-blasted titanium · black DLC",
    dial: "Champagne luminescence",
    price: 2400,
    image: IMG.frames[0],
    accent: "#c9a15f",
  },
  {
    id: "glacier",
    name: "Glacier GT",
    material: "Brushed 904L titanium",
    dial: "Ice-white luminescence",
    price: 2550,
    image: IMG.editionGlacier,
    accent: "#bfd9e2",
  },
  {
    id: "aurum",
    name: "Aurum GT",
    material: "Rose-gold PVD titanium",
    dial: "Warm amber luminescence",
    price: 3200,
    image: IMG.editionAurum,
    accent: "#d9a05b",
  },
];

export const TICKER = [
  "GRADE-5 TITANIUM",
  "100 M WATER RESIST",
  "21-DAY RESERVE",
  "SAPPHIRE · 2.5 MM",
  "DUAL-BAND GNSS",
  "120 HZ LTPO DISPLAY",
  "68 GRAMS",
  "CALIBRE M-2",
  "500 NUMBERED UNITS",
  "BIEL/BIENNE · SWITZERLAND",
];

export interface AnatomyItem {
  no: string;
  title: string;
  body: string;
  spec: string;
  image: string;
}

export const ANATOMY: AnatomyItem[] = [
  {
    no: "01",
    title: "The Case",
    body: "A single billet of grade-5 titanium, machined over nine hours into an octagon with chamfered, hand-polished edges. Micro-blasted to a matte that swallows light — then DLC-sealed against a decade of rock faces.",
    spec: "41.5 mm · tolerance ±4 µm",
    image: IMG.frames[4],
  },
  {
    no: "02",
    title: "The Crown",
    body: "Twenty-four knurled detents cut at 0.1 mm pitch, each one a tactile click you can feel through a climbing glove. Press, turn, hold — the whole instrument answers through one fingertip.",
    spec: "Haptic corona · 316L core",
    image: IMG.frames[1],
  },
  {
    no: "03",
    title: "The Dial",
    body: "A 1.43-inch LTPO panel under 2.5 mm of domed sapphire. It idles at one hertz to sip power, then wakes to 120 hertz the instant your wrist turns — 3,000 nits against a noon glacier.",
    spec: "466 × 466 · 3 000 nits",
    image: IMG.frames[3],
  },
  {
    no: "04",
    title: "The Engine",
    body: "Calibre M-2 is a silicon movement in the old sense of the word: a dual-core chronometer engine regulated by a temperature-compensated oscillator, tuned in Bienne to drift less than a heartbeat a year.",
    spec: "TCXO ±0.3 s / yr",
    image: IMG.frames[2],
  },
  {
    no: "05",
    title: "The Strap",
    body: "FKM fluoroelastomer, cured slow and finished with a laser-etched topography map of the Eiger north face. Titanium pin buckle, quick-release pins — swapped in four seconds, held for a lifetime.",
    spec: "FKM · 22 mm · 9 g",
    image: IMG.frames[5],
  },
];

export const METRICS = [
  { value: 21, suffix: " days", label: "Power reserve", note: "GPS off · AOD on" },
  { value: 100, suffix: " m", label: "Water resistance", note: "EN 22810 certified" },
  { value: 68, suffix: " g", label: "Total mass", note: "Strap included" },
  { value: 120, suffix: " Hz", label: "Dial refresh", note: "LTPO · 1–120 adaptive" },
  { value: 9, suffix: " h", label: "GNSS tracking", note: "Dual-band, continuous" },
];
