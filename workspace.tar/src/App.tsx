import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { IMG } from "./data/catalog";
import BootLoader from "./components/BootLoader";
import Nav from "./components/Nav";
import HeroFrames from "./components/HeroFrames";
import Marquee from "./components/Marquee";
import Metrics from "./components/Metrics";
import Anatomy from "./components/Anatomy";
import LiveDial from "./components/LiveDial";
import Lifestyle from "./components/Lifestyle";
import Editions from "./components/Editions";
import Reserve from "./components/Reserve";
import Footer from "./components/Footer";
import { ToastHost } from "./components/ui";

const ALL_SOURCES: string[] = [
  ...IMG.frames,
  IMG.editionGlacier,
  IMG.editionAurum,
  IMG.lifestyle,
];

export default function App() {
  const [progress, setProgress] = useState(0);
  const [framesReady, setFramesReady] = useState(false);
  const imgsRef = useRef<HTMLImageElement[] | null>(null);

  if (imgsRef.current === null) {
    // Create image handles synchronously so the hero can reuse them.
    imgsRef.current = ALL_SOURCES.map((src) => {
      const img = new Image();
      img.decoding = "async";
      img.src = src;
      return img;
    });
  }

  useEffect(() => {
    const imgs = imgsRef.current ?? [];
    let loaded = 0;
    let framesLoaded = 0;
    const total = imgs.length;

    const bump = (isFrame: boolean) => {
      loaded += 1;
      if (isFrame) {
        framesLoaded += 1;
        if (framesLoaded >= IMG.frames.length) setFramesReady(true);
      }
      setProgress(loaded / total);
    };

    imgs.forEach((img, i) => {
      const isFrame = i < IMG.frames.length;
      if (img.complete && img.naturalWidth > 0) {
        bump(isFrame);
      } else {
        img.addEventListener("load", () => bump(isFrame), { once: true });
        img.addEventListener("error", () => bump(isFrame), { once: true });
      }
    });
  }, []);

  const onBootDone = useCallback(() => {
    /* boot overlay dismissed — page is live */
  }, []);

  const frameImages = useMemo(
    () => (imgsRef.current ?? []).slice(0, IMG.frames.length),
    []
  );

  return (
    <div className="relative min-h-screen bg-carbon text-mist overflow-x-clip">
      <BootLoader progress={progress} ready={framesReady} onDone={onBootDone} />

      <Nav />

      <main>
        <HeroFrames images={frameImages} />
        <Marquee />
        <Metrics />
        <Anatomy />
        <LiveDial />
        <Lifestyle />
        <Editions />
        <Reserve />
      </main>

      <Footer />

      <ToastHost />
      <div className="noise-overlay" aria-hidden="true" />
    </div>
  );
}
