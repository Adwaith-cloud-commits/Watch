import { db } from "./db";
import { ApiError } from "./types";
import type {
  ApiLogEntry,
  ApiStatus,
  Inventory,
  ReserveInput,
  ReserveResult,
} from "./types";

/**
 * Simulated REST layer.
 * Every call is async, latency-shaped like a real edge API
 * (180–420 ms), validates input, and persists through `db`.
 * Swap the internals for fetch() calls and the contracts hold.
 */

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function log(endpoint: string, ms: number, code: number): void {
  const entry: ApiLogEntry = { endpoint, ms: Math.round(ms), code, ts: Date.now() };
  db.setLastCall(entry);
  window.dispatchEvent(new CustomEvent("kronwerk:api", { detail: entry }));
}

function delay(): Promise<number> {
  const ms = 180 + Math.random() * 240;
  return new Promise((resolve) => setTimeout(() => resolve(ms), ms));
}

function refCode(): string {
  const alphabet = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < 4; i += 1) {
    s += alphabet[Math.floor(Math.random() * alphabet.length)];
  }
  return `GT-${new Date().getFullYear().toString().slice(2)}${s}`;
}

export const api = {
  async fetchInventory(): Promise<Inventory> {
    const ms = await delay();
    log("GET /v1/inventory", ms, 200);
    return db.getInventory();
  },

  async reserveUnit(input: ReserveInput): Promise<ReserveResult> {
    const started = performance.now();
    const ms = await delay();

    const name = input.name.trim();
    const email = input.email.trim();
    const editionId = input.editionId;

    const fail = (message: string, code: number): never => {
      log("POST /v1/reservations", ms, code);
      throw new ApiError(message, code);
    };

    if (name.length < 2) fail("Name must be at least 2 characters.", 422);
    if (!EMAIL_RE.test(email)) fail("Enter a valid email address.", 422);
    if (!["S", "M", "L"].includes(input.wrist)) fail("Select a wrist size.", 422);

    const inv = db.getInventory();
    const entry = inv[editionId];
    if (!entry) fail("Unknown edition.", 404);
    if (entry.stock <= 0) fail("This edition's allocation is exhausted.", 409);

    const existing = db.findOrder(email, editionId);
    if (existing) {
      fail(
        `An allocation already exists for this email — reference ${existing.ref}.`,
        409
      );
    }

    const position = entry.total - entry.stock + 1;
    const ref = refCode();
    db.insertOrder({
      ref,
      editionId,
      name,
      email,
      wrist: input.wrist,
      position,
      ts: Date.now(),
    });
    const remaining = db.decrementStock(editionId);

    log("POST /v1/reservations", ms, 201);
    void started;
    return { ref, position, editionId, remaining };
  },

  async subscribe(emailRaw: string): Promise<{ email: string }> {
    const ms = await delay();
    const email = emailRaw.trim().toLowerCase();
    if (!EMAIL_RE.test(email)) {
      log("POST /v1/subscribers", ms, 422);
      throw new ApiError("Enter a valid email address.", 422);
    }
    if (db.getSubscribers().includes(email)) {
      log("POST /v1/subscribers", ms, 409);
      throw new ApiError("This address is already on the Meridian list.", 409);
    }
    db.insertSubscriber(email);
    log("POST /v1/subscribers", ms, 201);
    return { email };
  },

  async getStatus(): Promise<ApiStatus> {
    const ms = await delay();
    log("GET /v1/status", ms, 200);
    return {
      online: true,
      orders: db.getOrders().length,
      subscribers: db.getSubscribers().length,
      inventory: db.getInventory(),
      lastCall: db.getLastCall(),
    };
  },
};
