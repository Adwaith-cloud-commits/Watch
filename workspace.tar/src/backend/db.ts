import type { ApiLogEntry, Inventory, OrderRecord } from "./types";

/**
 * Persistence layer for the Kronwerk demo backend.
 * Mirrors a tiny embedded database: reads/writes localStorage
 * synchronously, namespaced and versioned.
 */
const NS = "kronwerk.v1";
const KEYS = {
  inventory: `${NS}.inventory`,
  orders: `${NS}.orders`,
  subscribers: `${NS}.subscribers`,
  lastCall: `${NS}.lastcall`,
} as const;

const INITIAL_INVENTORY: Inventory = {
  stealth: { stock: 347, total: 500 },
  glacier: { stock: 452, total: 500 },
  aurum: { stock: 188, total: 500 },
};

function read<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function write(key: string, value: unknown): void {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage unavailable — run in-memory */
  }
}

export const db = {
  getInventory(): Inventory {
    const stored = read<Inventory | null>(KEYS.inventory, null);
    if (stored) return stored;
    write(KEYS.inventory, INITIAL_INVENTORY);
    return { ...INITIAL_INVENTORY };
  },

  decrementStock(editionId: string): number {
    const inv = db.getInventory();
    const entry = inv[editionId];
    if (!entry) throw new Error("Unknown edition");
    entry.stock = Math.max(0, entry.stock - 1);
    write(KEYS.inventory, inv);
    return entry.stock;
  },

  getOrders(): OrderRecord[] {
    return read<OrderRecord[]>(KEYS.orders, []);
  },

  insertOrder(order: OrderRecord): void {
    const orders = db.getOrders();
    orders.push(order);
    write(KEYS.orders, orders);
  },

  findOrder(email: string, editionId: string): OrderRecord | undefined {
    return db
      .getOrders()
      .find(
        (o) =>
          o.email.toLowerCase() === email.toLowerCase() &&
          o.editionId === editionId
      );
  },

  getSubscribers(): string[] {
    return read<string[]>(KEYS.subscribers, []);
  },

  insertSubscriber(email: string): void {
    const subs = db.getSubscribers();
    subs.push(email.toLowerCase());
    write(KEYS.subscribers, subs);
  },

  getLastCall(): ApiLogEntry | null {
    return read<ApiLogEntry | null>(KEYS.lastCall, null);
  },

  setLastCall(entry: ApiLogEntry): void {
    write(KEYS.lastCall, entry);
  },
};
