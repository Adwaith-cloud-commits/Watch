export interface InventoryEntry {
  stock: number;
  total: number;
}

export type Inventory = Record<string, InventoryEntry>;

export interface OrderRecord {
  ref: string;
  editionId: string;
  name: string;
  email: string;
  wrist: string;
  position: number;
  ts: number;
}

export interface ReserveInput {
  editionId: string;
  name: string;
  email: string;
  wrist: string;
}

export interface ReserveResult {
  ref: string;
  position: number;
  editionId: string;
  remaining: number;
}

export interface ApiLogEntry {
  endpoint: string;
  ms: number;
  code: number;
  ts: number;
}

export interface ApiStatus {
  online: boolean;
  orders: number;
  subscribers: number;
  inventory: Inventory;
  lastCall: ApiLogEntry | null;
}

export class ApiError extends Error {
  code: number;
  constructor(message: string, code = 400) {
    super(message);
    this.code = code;
  }
}
